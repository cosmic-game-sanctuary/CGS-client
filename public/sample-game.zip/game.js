/* Deep Six - a tiny one-button descent, used as a test fixture for the
   in-browser build preview. Loads its palette at runtime from assets/, which
   is the part that proves the service worker is serving the whole build and
   not just the entry file. */

const canvas = document.getElementById('stage')
const ctx = canvas.getContext('2d')
const W = canvas.width
const H = canvas.height

let P = null
let rows = []
let depth = 0
let best = 0
let speed = 1.6
let x = W / 2
let held = false
let dead = false
let started = false
let rowOffset = 0

const ROW_H = 20

function makeRow(previous) {
  const width = Math.max(
    P.gapMin,
    P.gapMax - depth * 0.06 + (Math.random() * 30 - 15),
  )
  const drift = (Math.random() - 0.5) * 70
  const centre = previous
    ? Math.min(W - width / 2 - 8, Math.max(width / 2 + 8, previous.centre + drift))
    : W / 2
  return {
    centre,
    width,
    rock: Math.random() < 0.14 ? Math.random() : null,
  }
}

function reset() {
  rows = []
  let last = null
  for (let i = 0; i < H / ROW_H + 3; i += 1) {
    last = makeRow(last)
    rows.push(last)
  }
  depth = 0
  speed = 1.6
  x = W / 2
  dead = false
  rowOffset = 0
}

function step() {
  if (!dead && started) {
    x += held ? 2.6 : -2.6
    x = Math.min(W - 10, Math.max(10, x))

    speed = 1.6 + depth * 0.0016
    rowOffset += speed
    while (rowOffset >= ROW_H) {
      rowOffset -= ROW_H
      rows.shift()
      rows.push(makeRow(rows[rows.length - 1]))
      depth += 1
    }

    // The row the lantern currently sits in.
    const index = Math.floor((H * 0.72) / ROW_H)
    const row = rows[index]
    if (row) {
      const left = row.centre - row.width / 2
      const right = row.centre + row.width / 2
      if (x < left + 6 || x > right - 6) dead = true
      if (row.rock !== null) {
        const rockX = left + row.rock * row.width
        if (Math.abs(x - rockX) < 12) dead = true
      }
    }
    if (dead) best = Math.max(best, depth)
  }
  draw()
  requestAnimationFrame(step)
}

function draw() {
  ctx.fillStyle = '#14110d'
  ctx.fillRect(0, 0, W, H)

  rows.forEach((row, i) => {
    const y = i * ROW_H - rowOffset
    const left = row.centre - row.width / 2
    const right = row.centre + row.width / 2
    ctx.fillStyle = P.wall
    ctx.fillRect(0, y, left, ROW_H + 1)
    ctx.fillRect(right, y, W - right, ROW_H + 1)
    if (row.rock !== null) {
      ctx.fillStyle = P.rock
      const rockX = left + row.rock * row.width
      ctx.fillRect(rockX - 7, y + 4, 14, 12)
    }
  })

  const py = H * 0.72
  ctx.fillStyle = P.glow
  ctx.globalAlpha = 0.25
  ctx.beginPath()
  ctx.arc(x, py, 34, 0, Math.PI * 2)
  ctx.fill()
  ctx.globalAlpha = 1
  ctx.fillStyle = P.lamp
  ctx.fillRect(x - 6, py - 6, 12, 12)

  ctx.fillStyle = '#fbf3e2'
  ctx.font = 'bold 16px ui-monospace, monospace'
  ctx.fillText(`${depth}m`, 12, 26)
  if (best) ctx.fillText(`best ${best}m`, 12, 46)

  if (!started || dead) {
    ctx.fillStyle = 'rgba(20,17,13,.78)'
    ctx.fillRect(0, H / 2 - 44, W, 88)
    ctx.fillStyle = '#fbf3e2'
    ctx.textAlign = 'center'
    ctx.font = 'bold 22px ui-monospace, monospace'
    ctx.fillText(dead ? `You made ${depth}m` : 'DEEP SIX', W / 2, H / 2 - 6)
    ctx.font = '12px ui-monospace, monospace'
    ctx.fillText(
      dead ? 'Click or press space to go again' : 'Hold to drift right. Release to drift left.',
      W / 2,
      H / 2 + 20,
    )
    ctx.textAlign = 'left'
  }
}

function press(event) {
  if (event) event.preventDefault()
  if (!started) {
    started = true
    return
  }
  if (dead) {
    reset()
    return
  }
  held = true
}

function release() {
  held = false
}

addEventListener('pointerdown', press)
addEventListener('pointerup', release)
addEventListener('keydown', (event) => {
  if (event.code === 'Space' || event.code === 'ArrowRight') press(event)
})
addEventListener('keyup', (event) => {
  if (event.code === 'Space' || event.code === 'ArrowRight') release()
})

// Runtime fetch of a sibling asset - this is the bit that only works if the
// whole build is being served, not just index.html.
fetch('assets/palette.json')
  .then((response) => response.json())
  .then((palette) => {
    P = palette
    reset()
    step()
  })
  .catch(() => {
    document.getElementById('hint').textContent =
      'Could not load assets/palette.json'
  })
